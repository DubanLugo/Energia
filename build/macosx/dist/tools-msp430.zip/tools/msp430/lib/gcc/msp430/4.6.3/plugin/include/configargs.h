/* Generated automatically. */
static const char configuration_arguments[] = "../../gcc/configure --enable-languages=c,c++ --disable-nls --target=msp430 --prefix=/Users/rwessels/opt/mspgcc_energia --with-pkgversion='MSPGCC 20120406 (With patches: sf3540953 sf3559978)'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
